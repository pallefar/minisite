#!/bin/bash
set -e
PORT=8420
DIR="$(cd "$(dirname "$0")" && pwd)"

clear
echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║  📦 minisite — App Builder & Demo                ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# Check files
MISSING=0
for f in app/index.html build/setup.html build/updater.html demo.html; do
    if [ ! -f "$DIR/$f" ]; then echo "  ❌ Missing: $f"; MISSING=1; fi
done
if [ "$MISSING" = "1" ]; then echo ""; echo "  Files missing from: $DIR"; exit 1; fi
echo "  ✅ All files found"
echo "  📂 $DIR"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "  [1]  🧪  Demo & Test"
echo "       Preview every page with 30 days of sample"
echo "       data. Run the pre-deploy checklist."
echo ""
echo "  [2]  🆕  New Build"
echo "       Configure branding, ads, Stripe, email"
echo "       and download all site files."
echo ""
echo "  [3]  🔄  Update Existing Build"
echo "       Change ads, Stripe, email, branding."
echo "       Dashboard links stay intact."
echo ""
echo "  [4]  ❌  Exit"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
read -p "  Enter choice [1/2/3/4]: " CHOICE
echo ""

case "$CHOICE" in
    1) PAGE="demo.html"; LABEL="Demo & Test Dashboard" ;;
    2) PAGE="build/setup.html"; LABEL="Setup Wizard (New Build)" ;;
    3) PAGE="build/updater.html"; LABEL="App Updater" ;;
    4) echo "  Bye! 👋"; exit 0 ;;
    *) echo "  Invalid. Run again."; exit 1 ;;
esac

while lsof -i :$PORT >/dev/null 2>&1; do PORT=$((PORT + 1)); done
URL="http://localhost:$PORT/$PAGE"

open_browser() {
    if command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL" 2>/dev/null &
    elif command -v open >/dev/null 2>&1; then open "$URL" 2>/dev/null &
    elif command -v start >/dev/null 2>&1; then start "$URL" 2>/dev/null &
    else echo "  ⚠️  Open manually: $URL"; fi
}

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "  $LABEL"
echo "  👉 $URL"
echo ""
if [ "$CHOICE" = "1" ]; then
    echo "  Test flow:"
    echo "  1. Click 'Inject Demo Data' for 30 days of logs"
    echo "  2. Open Dashboard to test all 8 tabs + charts"
    echo "  3. Open each sub-page (privacy, terms, etc.)"
    echo "  4. Run the pre-deploy checklist"
    echo "  5. Test the Setup Wizard and Updater"
    echo ""
    echo "  Pages to verify:"
    echo "  • Landing (light mode, ads, cookie banner)"
    echo "  • Dashboard (all tabs, offers, ebook modal)"
    echo "  • Privacy, Terms, About, Contact, Advertise"
    echo "  • Wizard (3-step, unique link generation)"
elif [ "$CHOICE" = "2" ]; then
    echo "  Steps: Fill config → Build → Download All 7 Files"
    echo ""
    echo "  Output: index.html + 6 sub-pages + sitemap + robots"
else
    echo "  Steps: Drag file → Change settings → Download"
    echo ""
    echo "  ⚡ Dashboard links are NEVER modified"
fi
echo ""
echo "  Press Ctrl+C to stop."
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

if command -v python3 >/dev/null 2>&1; then open_browser; cd "$DIR" && python3 -m http.server $PORT 2>/dev/null
elif command -v python >/dev/null 2>&1; then open_browser; cd "$DIR" && python -m http.server $PORT 2>/dev/null
elif command -v npx >/dev/null 2>&1; then open_browser; cd "$DIR" && npx -y http-server -p $PORT -c-1 --silent 2>/dev/null
elif command -v php >/dev/null 2>&1; then open_browser; cd "$DIR" && php -S localhost:$PORT 2>/dev/null
else echo "  ❌ No server found. Install python3, nodejs, or php."; exit 1; fi
