#!/bin/bash
#
# minisite — GitHub Repo Setup Script
# =====================================
# Run this once to create the repo and push all files.
#
# Prerequisites:
#   - GitHub CLI installed: brew install gh (Mac) or apt install gh (Linux)
#   - Authenticated: gh auth login
#
# Usage: chmod +x github-setup.sh && ./github-setup.sh
#

set -e

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║  📦 minisite — GitHub Setup                      ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# Check if gh is installed
if ! command -v gh &>/dev/null; then
    echo "❌ GitHub CLI (gh) is not installed."
    echo ""
    echo "Install it:"
    echo "  Mac:    brew install gh"
    echo "  Linux:  sudo apt install gh"
    echo "  Windows: winget install GitHub.cli"
    echo ""
    echo "Then authenticate: gh auth login"
    echo ""
    echo "Or create the repo manually:"
    echo "  1. Go to https://github.com/new"
    echo "  2. Create repo named 'minisite'"
    echo "  3. Run these commands:"
    echo "     cd $(pwd)"
    echo "     git init"
    echo "     git add ."
    echo "     git commit -m 'Initial commit: minisite template system'"
    echo "     git branch -M main"
    echo "     git remote add origin https://github.com/YOUR_USERNAME/minisite.git"
    echo "     git push -u origin main"
    exit 1
fi

# Check auth
if ! gh auth status &>/dev/null; then
    echo "❌ Not authenticated with GitHub."
    echo "   Run: gh auth login"
    exit 1
fi

USERNAME=$(gh api user -q .login)
echo "  👤 GitHub user: $USERNAME"
echo ""

# Check if repo exists
if gh repo view "$USERNAME/minisite" &>/dev/null; then
    echo "  ⚠️  Repo $USERNAME/minisite already exists."
    read -p "  Push to existing repo? [y/N]: " CONFIRM
    if [ "$CONFIRM" != "y" ] && [ "$CONFIRM" != "Y" ]; then
        echo "  Cancelled."
        exit 0
    fi
else
    echo "  Creating repo: $USERNAME/minisite"
    read -p "  Make it public or private? [public/private]: " VISIBILITY
    VISIBILITY=${VISIBILITY:-public}
    gh repo create minisite --"$VISIBILITY" --description "Template system for building free, monetizable single-page tracker/dashboard web apps" --clone=false
    echo "  ✅ Repo created: https://github.com/$USERNAME/minisite"
fi

echo ""
echo "  📤 Pushing files..."

# Init and push
if [ ! -d .git ]; then
    git init
    git branch -M main
fi

# Set remote
REMOTE_URL="https://github.com/$USERNAME/minisite.git"
if git remote get-url origin &>/dev/null; then
    git remote set-url origin "$REMOTE_URL"
else
    git remote add origin "$REMOTE_URL"
fi

# Create .gitignore
cat > .gitignore << 'EOF'
.DS_Store
config.json
*.bak
node_modules/
EOF

git add .
git commit -m "Initial commit: minisite template system

- Main app (index.html) with landing page, dashboard, wizard
- 8 sub-pages: privacy, terms, about, contact, advertise, offers, sitemap, robots
- Build tools: setup wizard (8-step), updater (drag-and-drop)
- Templates with %%PLACEHOLDER%% tokens
- Claude Code skill (SKILL.md)
- Interactive launcher (launch.sh)
- AdSense-compliant, GDPR-ready, Stripe-integrated"

git push -u origin main

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "  ✅ Done! Your repo is live at:"
echo "  👉 https://github.com/$USERNAME/minisite"
echo ""
echo "  Clone it anywhere:"
echo "  git clone https://github.com/$USERNAME/minisite.git"
echo ""
echo "  For Claude Code skill, add this to your project:"
echo "  /mnt/skills/user/tracker-app-builder/SKILL.md"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
