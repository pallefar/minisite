# minisite

**A template system for building free, monetizable single-page tracker/dashboard web apps.**

Build complete sites with ad monetization, Stripe payments, newsletter integration, affiliate offers, and legal pages — all from a single HTML file. No backend, no framework, no build step.

## What You Get

| Folder | Contents | Purpose |
|--------|----------|---------|
| `app/` | 9 files | Deploy these to your host |
| `build/` | 2 files | Setup wizard + updater (keep locally) |
| `templates/` | 10 files | Raw templates with `%%PLACEHOLDER%%` tokens |
| `launch.sh` | 1 file | Interactive launcher script |
| `SKILL.md` | 1 file | Claude Code skill for building new apps |

## Quick Start

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/minisite.git
cd minisite

# Run the launcher
chmod +x launch.sh
./launch.sh
```

Choose **[1] New Build** to configure your app, or **[2] Update** to modify an existing build.

## Repo Structure

```
minisite/
├── app/                          # ← Upload these files to your host
│   ├── index.html                # Main app (landing + dashboard)
│   ├── privacy.html              # GDPR privacy policy
│   ├── terms.html                # Terms of service
│   ├── about.html                # About page
│   ├── contact.html              # Contact page
│   ├── advertise.html            # Media kit
│   ├── offers.html               # Affiliate deals
│   ├── sitemap.xml               # Search engine sitemap
│   └── robots.txt                # Crawler directives
├── build/                        # ← Keep locally, don't deploy
│   ├── setup.html                # 8-step visual config wizard
│   └── updater.html              # Drag-and-drop config modifier
├── templates/                    # ← Raw templates with placeholders
│   ├── template.html             # Main app template
│   ├── privacy.tpl.html
│   ├── terms.tpl.html
│   ├── about.tpl.html
│   ├── contact.tpl.html
│   ├── advertise.tpl.html
│   ├── offers.tpl.html
│   ├── sitemap.tpl.xml
│   └── robots.tpl.txt
├── launch.sh                     # Interactive launcher
├── SKILL.md                      # Claude Code skill
└── README.md
```

## Setup Wizard (8 Steps)

1. **Branding** — App name, tagline, domain, contact emails
2. **Advertising** — AdSense, custom banners, embed codes, ad rotator
3. **Stripe** — Ebook payments (test/live mode), webhooks
4. **Email** — Newsletter provider, subscribe endpoint
5. **Analytics** — Google Analytics 4, Plausible
6. **Affiliates** — Supplement and equipment affiliate links
7. **Membership & Resources** — External login button + resources tab
8. **Offers** — Featured deal + 9 affiliate offer slots across 4 categories

## Monetization Built In

- **15+ ad slots** with rotation engine (AdSense, custom banners, embed codes)
- **Newsletter** with dashboard link delivery + weekly digest
- **Ebook upsell** ($5 Stripe payment with metadata forwarding for auto-generation)
- **Affiliate offers** page (4 categories, 9 product slots)
- **Membership button** (link to external membership site)
- **Resources link** (configurable external link in tab bar)

## AdSense Compliance

All required pages for Google AdSense approval are included:
- ✅ Privacy Policy (GDPR/CCPA, cookies, third parties)
- ✅ Terms of Service (disclaimer, liability, IP)
- ✅ About page (mission, features, monetization transparency)
- ✅ Contact page (4 departments including GDPR)
- ✅ Cookie consent banner
- ✅ No broken links
- ✅ Consistent navigation

## Using as a Template for Other Niches

This template works for any tracker/dashboard app. See `SKILL.md` for the full guide, or use Claude Code:

```
"Create a personal finance tracker using the minisite template"
"Build a pet health dashboard from the minisite repo"
"Make a habit tracking app following the minisite pattern"
```

The Claude Code skill handles research, planning, and generation for any niche.

## Deployment

Upload the `app/` folder contents to any static host:
- **Vercel**: `cd app && vercel`
- **Netlify**: drag the `app/` folder into Netlify dashboard
- **Cloudflare Pages**: connect repo, set `app/` as build output
- **GitHub Pages**: enable in repo settings, set source to `app/` folder

## License

MIT — use for any project, commercial or personal.
