---
name: tracker-app-builder
description: Build complete, monetizable single-page tracker/dashboard web apps from a proven template. Use when the user wants to create a tracker, dashboard, planner, or monitoring app on ANY topic — health, finance, habits, pets, learning, gardening, etc. Covers niche research, keyword analysis, domain selection, app generation, ad/payment/email integration, legal pages, and deployment. Produces a full site package (app + 7 sub-pages + build tools) ready to deploy.
---

# Tracker App Builder

Build production-ready, monetizable single-page tracker/dashboard web apps on any topic using the **minisite** template system.

**Template repo:** `https://github.com/USER/minisite` (clone and customize)

## Setup

To use this skill with Claude Code:
1. Clone the template repo: `git clone https://github.com/USER/minisite.git`
2. Copy `SKILL.md` to `/mnt/skills/user/tracker-app-builder/SKILL.md`
3. Copy the `templates/` folder alongside the skill
4. When building a new app, Claude will clone the repo, replace placeholders, and output a ready-to-deploy site

## When to Use This Skill

Trigger when the user wants to:
- Create a tracker, dashboard, or monitoring app on any topic
- Build a free tool with ad monetization, newsletter, and digital product upsell
- Create a "micro-SaaS" style single-page app with no backend
- Clone the BodyRecomp/BodyOS template pattern for a different niche
- Research a niche and build a complete deployable site package

Keywords: tracker app, dashboard builder, health tracker, habit tracker, finance tracker, planner app, monitoring dashboard, free tool, micro-saas, single page app template

## Architecture Overview

Every app follows this proven structure:

```
{project-name}/
├── app/                          # Deploy these files
│   ├── index.html                # Main app (landing + dashboard + wizard)
│   ├── privacy.html              # GDPR privacy policy
│   ├── terms.html                # Terms of service + disclaimer
│   ├── about.html                # About page
│   ├── contact.html              # Contact page
│   ├── advertise.html            # Media kit / ad sales
│   ├── offers.html               # Affiliate deals (SEO page)
│   ├── sitemap.xml               # Search engine sitemap
│   └── robots.txt                # Crawler directives
├── build/                        # Keep locally, don't deploy
│   ├── template.html             # App template (%%PLACEHOLDERS%%)
│   ├── setup.html                # Visual 8-step config wizard
│   ├── updater.html              # Drag-and-drop config modifier
│   ├── privacy.tpl.html          # Sub-page templates
│   ├── terms.tpl.html
│   ├── about.tpl.html
│   ├── contact.tpl.html
│   ├── advertise.tpl.html
│   └── offers.tpl.html
├── launch.sh                     # Interactive launcher (New / Update)
├── config.json                   # Saved configuration
└── README.md                     # Deployment instructions
```

## Naming Conventions

### Project Naming
- Format: `{topic}{action}` or `{action}{topic}` — e.g. `BodyRecomp`, `BudgetPulse`, `PlantLog`, `HabitStack`
- Must be: short (≤12 chars), memorable, available as `.app` or `.co` domain
- Avoid: generic words alone (`Tracker`, `Dashboard`), hyphens, numbers

### File Naming
- Main app: always `index.html` in deployment
- Template: always `template.html` in build/
- Sub-pages: lowercase, single-word: `privacy.html`, `terms.html`, `about.html`, `contact.html`, `advertise.html`, `offers.html`
- Config: `config.json`
- Launch script: `launch.sh`

### Placeholder Naming
All configurable values use `%%DOUBLE_PERCENT%%` tokens:
- `%%SITE_NAME%%` — app name
- `%%SITE_DOMAIN%%` — domain
- `%%CONTACT_EMAIL%%` — contact email
- `%%ADS_EMAIL%%` — advertising email
- `%%DATE%%` — build date
- `%%MEMBER_URL%%`, `%%MEMBER_LABEL%%` — membership button
- `%%RESOURCES_URL%%`, `%%RESOURCES_LABEL%%` — resources tab
- `%%OFFER_*%%` — affiliate offer slots

### CSS Variable Naming
```css
--bg     /* background */
--s1-s4  /* surface levels 1-4 (lightest to darkest) */
--border /* default border */
--cyan   /* primary accent */
--lime   /* success/positive */
--orange /* warning/attention */
--purple /* secondary accent */
--gold   /* premium/upsell */
--red    /* error/negative */
--text   /* primary text */
--t2     /* secondary text */
--t3     /* tertiary/muted text */
--fd     /* display font */
--fb     /* body font */
--fm     /* monospace font */
```

## Workflow: Discover → Research → Plan → Build

### Phase 0: Discovery (MANDATORY — ask before doing anything)

**CRITICAL: Before ANY research or building, ask the user ALL questions below in a single structured prompt. Do NOT start building until every section has an answer or explicit "skip". Present these as a numbered questionnaire the user fills in.**

```
═══════════════════════════════════════════════════════════
  MINISITE BUILDER — Project Discovery Questionnaire
═══════════════════════════════════════════════════════════

Please answer each section. Type "skip" for any you want
me to decide. The more detail you give, the better the
output.

─── 1. CORE CONCEPT ────────────────────────────────────

1.1 What does this app track/help with?
    (e.g. "body transformation", "personal budget",
     "garden plants", "study habits")

1.2 Who is the target user? 
    (age range, interests, skill level, problems they have)

1.3 What problem does this solve that existing tools don't?
    (or what's frustrating about current options?)

1.4 Do you have a name in mind? 
    (or should I research and suggest 5 options?)

1.5 Do you have a domain already?
    (or should I suggest available domains?)

─── 2. WHAT USERS TRACK ───────────────────────────────

2.1 What daily metrics should users log?
    (e.g. weight, calories, mood, spending, hours studied)
    List 4-8 key metrics:

2.2 What weekly/monthly metrics? (if any)
    (e.g. body measurements, net worth, test scores)

2.3 Should there be a morning/daily routine checklist?
    If yes, list the default habits:

2.4 What goals do users set in the wizard?
    (e.g. "lose 10kg", "save $5000", "read 20 books")
    List 6-8 goal options:

─── 3. DASHBOARD TABS ─────────────────────────────────

2.5 What tabs should the dashboard have?
    Default template has: Overview, Tracker, Advanced,
    Forecast, Guide, Workouts, Offers, Ebook.
    
    Rename or replace any? Add custom tabs?
    (e.g. rename "Nutrition" to "Budget Categories",
     add "Community" tab)

─── 4. CONTENT & PROTOCOLS ────────────────────────────

4.1 What educational content should be included?
    (e.g. supplement protocols, budgeting rules,
     study techniques, plant care guides)

4.2 Should there be a checklist/protocol section?
    (like a supplement stack or daily habits)
    If yes, list 8-12 items with names and descriptions:

4.3 Any exercises/activities/actions to include
    with visual guides? (SVG illustrations will be
    generated for each)

4.4 Recipes, templates, or reusable content cards?
    (e.g. keto recipes, budget templates, study plans)
    How many? What categories?

─── 5. FORECASTING & PHASES ───────────────────────────

5.1 Should the app project future progress?
    (e.g. weight forecast, savings projection,
     grade prediction)

5.2 Are there phases to the journey?
    (e.g. "Weeks 1-4: Foundation", or 
     "Month 1: Track spending")
    List 3-4 phases if applicable:

─── 6. MONETIZATION ───────────────────────────────────

6.1 Ad networks: Google AdSense, or custom/direct?
    (or both with rotator?)

6.2 Digital product to sell: 
    What would the ebook/guide contain?
    What price? ($5, $9, $15?)

6.3 Affiliate offers — what product categories?
    List 3-5 categories relevant to the niche:
    (e.g. supplements, equipment, courses, software)

6.4 Membership site: Do you have an external
    membership/community to link to?
    Button label + URL:

6.5 Resources link: External blog/community URL?
    Tab label + URL:

─── 7. BRANDING & DESIGN ─────────────────────────────

7.1 Preferred color scheme?
    (e.g. "blue/green health feel", "dark finance look",
     "warm earthy garden theme")
    Or skip for auto-selection.

7.2 Tagline / value proposition?
    (one line, e.g. "Free body transformation tracker")

7.3 Any specific tone for the copy?
    (professional, casual, motivational, scientific)

─── 8. TECHNICAL & LEGAL ──────────────────────────────

8.1 Any niche-specific disclaimers needed?
    (e.g. "not medical advice", "not financial advice",
     "consult a professional")

8.2 Stripe: test mode or live? Payment link URL?
    (or set up later via the setup wizard?)

8.3 Email provider: Mailchimp, ConvertKit, Beehiiv?
    (or set up later?)

8.4 Google Analytics ID? (or later?)

8.5 Anything else I should know?

═══════════════════════════════════════════════════════════
```

**After receiving answers**, proceed to Phase 1. For any "skip" answers, make reasonable defaults based on the niche and document your choices for user approval before building.

**If the user gives a vague request** like "build me a finance tracker", DO NOT start building. Ask the questionnaire. A 2-minute questionnaire saves hours of revision.

**If the user gives detailed specs**, map their answers to the questionnaire fields and confirm: "Here's what I'll build — [summary]. Anything to change before I start?"

### Phase 1: Research (use web_search)

Before building, ALWAYS research the niche. Search for:

1. **Keyword volume**: `"{topic} tracker free"`, `"{topic} dashboard app"`, `"free {topic} planner"`
2. **Competitors**: `"best {topic} tracker app 2026"`, `"{topic} monitoring tool"`
3. **Pain points**: `"{topic} tracking problems"`, `"how to track {topic}"`
4. **Monetization**: `"{topic} affiliate programs"`, `"{topic} products to recommend"`
5. **Domain availability**: Check `{topicname}.app`, `{topicname}.co`, `my{topicname}.com`, `get{topicname}.com`, `{topicname}hub.com`

Document findings in a research brief:
```
NICHE: {topic}
TARGET AUDIENCE: {who uses this}
PRIMARY KEYWORDS: {3-5 high-volume, low-competition keywords}
COMPETITORS: {3-5 existing tools, their gaps}
MONETIZATION: {ad networks, affiliate programs, digital products}
DOMAIN CANDIDATES: {3-5 domain options with reasoning}
APP NAME: {chosen name}
TAGLINE: {one-line value proposition}
```

### Phase 2: Plan

Define the app structure. Every app needs:

1. **Landing page** (SEO-optimized, light mode default)
   - Hero: name, tagline, CTA, social proof counter
   - Features grid (6 cards)
   - How it works (4 steps)
   - Science/methodology section
   - Audience segments
   - FAQ (6 questions)
   - Ad blocks (5 on landing)
   - Cookie consent banner

2. **Setup wizard** (4 steps)
   - Step 1: User basics (name, demographics relevant to niche)
   - Step 2: Targets/goals (what they want to track + goal options from Q2.4)
   - Step 3: Daily routine builder (morning/daily habits checklist from Q2.3)
   - Step 4: Email opt-in + newsletter consent → generate unique dashboard link

3. **Dashboard tabs** (customize per niche, typically 7-9):
   - Overview/Today (daily metrics + visual representation + morning routine checklist)
   - Tracker (historical charts + log history + wearable data guide)
   - Advanced metrics (niche-specific deep tracking, e.g. biomarkers)
   - Forecast/Projections (goal timeline with phases)
   - Guide/Protocol (educational content + daily checklists)
   - Workouts/Actions (exercise library with SVG illustrations + session tracker)
   - Offers (affiliate deals — 4 categories, 9+ slots)
   - Resources (configurable external link tab)
   - Digital product upsell (ebook/guide purchase)

4. **Monetization layers**:
   - Ad blocks (15+ slots with rotator support)
   - Newsletter (weekly digest + affiliate promos)
   - Digital product ($5-$15 ebook/guide via Stripe)
   - Affiliate offers page (4 categories, 9+ slots)
   - Membership button (external site link)
   - Resources link (blog/community)

5. **Legal pages** (required for AdSense):
   - Privacy policy (GDPR/CCPA compliant, cookies, third parties)
   - Terms of service (disclaimer for niche, liability, IP)
   - About page (mission, features, sustainability model)
   - Contact page (4 departments: support, ads, business, privacy)
   - Advertise page (audience stats, pricing tiers, ad specs)
   - Offers page (SEO landing for affiliate deals)

### Phase 3: Build

Generate all files following the template architecture:

1. **Clone the template repo**: `git clone https://github.com/USER/minisite.git {project-name}`
2. **Read templates** from `templates/` folder — `template.html` is the main app, `*.tpl.html` are sub-pages
3. **Replace all `%%PLACEHOLDER%%` tokens** with the niche-specific values from the plan
4. **Customize the dashboard tabs** — rename, reorder, add/remove tabs for the niche
5. **Customize metrics** — replace health metrics with niche-specific ones (e.g. weight → net worth, steps → savings)
6. **Customize protocols/guides** — replace supplement stacks with niche-relevant checklists
7. **Customize recipes/content** — replace with niche-relevant content (e.g. recipes → budget templates)
8. **Update SEO** — title, meta description, keywords, schema.org, OG tags for the niche
9. **Update legal pages** — niche-specific disclaimers in terms.html
10. **Output to `app/`** — all deployable files
11. **Update `build/setup.html`** — customize the wizard fields for the niche
12. **Commit and push** to the project's own repo
   - CSS variables (dark + light theme)
   - Landing page with SEO meta, structured data, OG tags
   - Wizard overlay (3 steps)
   - Dashboard with all tabs
   - All JS: state management, localStorage, charts (Chart.js), routing, logging
   - Cookie consent, back-to-top, social proof, data export/import
   - Ad blocks with `data-ad-slot="N"` numbering
   - Ebook CTA modal (daily cookie)
   - Membership button + Resources tab (configurable)
3. **Generate sub-pages** — each with consistent nav, footer, and `%%PLACEHOLDER%%` tokens
4. **Generate build tools** — setup.html (8-step wizard), updater.html (drag-and-drop modifier), launch.sh (interactive menu)
5. **Generate sitemap.xml and robots.txt**

### Niche Adaptation Examples

| Niche | Tabs | Key Metrics | Digital Product | Affiliate Categories |
|---|---|---|---|---|
| Body/Health | Dashboard, Tracker, Biomarkers, Forecast, Nutrition, Protocol | Weight, BF%, HRV, Sleep, Steps, Calories | Transformation ebook | Supplements, Gear, Meals, Wellness |
| Personal Finance | Dashboard, Budget, Net Worth, Goals, Investments, Debt | Income, Expenses, Savings Rate, Net Worth | Financial plan PDF | Banking, Investing, Insurance, Tools |
| Habit Tracking | Dashboard, Habits, Streaks, Analytics, Routines, Journal | Completion %, Streaks, Mood, Energy | Habit mastery guide | Productivity apps, Books, Courses, Planners |
| Pet Health | Dashboard, Weight, Vet, Food, Activity, Medications | Weight, Meals, Walks, Vet visits, Meds | Pet care ebook | Pet food, Supplements, Insurance, Gear |
| Garden/Plants | Dashboard, Plants, Watering, Harvest, Weather, Soil | Plants, Water schedule, Yield, Sunlight | Seasonal guide PDF | Seeds, Tools, Soil, Planters |
| Learning/Study | Dashboard, Subjects, Hours, Tests, Resources, Schedule | Study hours, Scores, Completion, Streak | Study system guide | Courses, Books, Software, Tutoring |
| Meditation | Dashboard, Sessions, Streaks, Mood, Sleep, Heart Rate | Minutes, Streak, Mood score, HRV | Mindfulness ebook | Apps, Cushions, Retreats, Courses |

## Key Technical Patterns

### State Management
```javascript
const STORAGE_PREFIX = '{appname}_';
let state = { uid, name, startDate, logs:[], settings:{}, /* niche data */ };
function saveState(){ localStorage.setItem(STORAGE_PREFIX + state.uid, JSON.stringify(state)); }
```

### Hash Routing
```javascript
// #dash_{uid} → load user dashboard
// #setup → show admin setup page  
// #purchase-success → handle Stripe redirect
function route(){ /* parse location.hash, load state, show correct page */ }
```

### Daily Metrics Pattern
```javascript
function logToday(){
  const entry = { date: today(), /* collect all input values */ };
  const idx = state.logs.findIndex(l => l.date === today());
  if(idx >= 0) state.logs[idx] = entry;
  else state.logs.push(entry);
  saveState(); updateAll();
}
```

### Ad Rotator Injection
The setup wizard injects a self-contained ad rotator script that:
- Reads `AD_POOL` array (banner HTML, embed code, or affiliate links)
- Rotates ads across all `[data-ad-slot]` elements
- Supports weighted rotation, shuffle, fade/slide transitions
- Executes embedded `<script>` tags in ad units

### Ebook CTA Pattern
- Daily popup modal (localStorage cookie per date)
- CTA bar at bottom of every dashboard tab
- Stripe integration with metadata forwarding for auto-generation
- `#purchase-success` redirect handling

## Output Checklist

Before delivering, verify:
- [ ] All `%%PLACEHOLDER%%` tokens are documented
- [ ] Landing page defaults to light mode
- [ ] "No credit card required" messaging on hero
- [ ] Cookie consent banner with link to privacy.html
- [ ] All nav links point to real pages (no `href="#"`)
- [ ] Schema.org JSON-LD in `<head>`
- [ ] OG meta tags for social sharing
- [ ] Responsive design (mobile-first)
- [ ] Data export/import buttons on dashboard
- [ ] Social proof counter on landing page
- [ ] Back-to-top button
- [ ] 15+ ad slots with `data-ad-slot` numbering
- [ ] Ebook CTA on every tab
- [ ] setup.html generates ALL site files
- [ ] updater.html regenerates sub-pages on update
- [ ] launch.sh has New/Update menu
- [ ] sitemap.xml and robots.txt included
- [ ] Privacy policy covers: cookies, AdSense, GA4, Stripe, localStorage, GDPR rights
- [ ] Terms include niche-specific disclaimer
- [ ] About page explains monetization model
- [ ] Contact page has GDPR data request handling

## Conversation Handling Rules

### Rule 1: ALWAYS ask the questionnaire first
Never start building from a vague request. Even "build me a health tracker" needs the full questionnaire because the template has 50+ configurable elements. The 2-minute questionnaire eliminates revision cycles.

### Rule 2: Confirm before building
After gathering answers and completing research, present a **Build Summary** for approval:
```
BUILD SUMMARY
─────────────
App Name:        BudgetPulse
Domain:          budgetpulse.app  
Tagline:         "Free Personal Finance Dashboard"
Target User:     25-45 year olds wanting to track spending
Daily Metrics:   income, expenses, savings, investments (4)
Goals:           save $X, pay off debt, build emergency fund (6 options)
Morning Routine: review budget, check accounts, log expenses (8 habits)  
Tabs:            Overview, Tracker, Budget, Goals, Investments, Guide, Workouts→removed, Offers, Ebook
Exercises/SVGs:  N/A (removed for this niche)
Protocols:       Budgeting rules checklist (12 items)
Recipes→:        Budget templates (8 templates)
Phases:          Month 1: Track → Month 2: Optimize → Month 3: Automate → Month 4: Grow
Digital Product: "Personal Finance Blueprint" ebook, $9
Affiliate Cats:  Banking, Investing apps, Insurance, Financial tools
Disclaimer:      "Not financial advice"
Color Scheme:    Dark blue + green (money/trust)
──────────────────────────────────────────────────
Proceed? [Y / changes needed]
```

### Rule 3: Handle "skip" answers intelligently
When the user skips a section, fill it with the best default for the niche. Document what you chose:
- Skip name → research keywords, suggest 5, pick the best available domain
- Skip metrics → use the niche adaptation table defaults
- Skip routine → pick 5-6 relevant morning habits for the niche
- Skip affiliate categories → research "{niche} affiliate programs" and pick top 4
- Skip color scheme → choose based on niche psychology (health=cyan/green, finance=blue/dark, garden=green/earth, learning=purple/blue)
- Skip disclaimer → use the standard template with niche keyword swap

### Rule 4: Map non-standard requests to the template
When a user asks for something that doesn't obviously map to a "tracker":
- "Build me a recipe site" → Food tracker with recipes as the primary content, track meals/macros
- "Build a journal app" → Habit/mood tracker with journal entries as the daily log
- "Build a portfolio" → This skill is NOT for portfolios/marketing sites. Decline and suggest a different approach.
- "Build a store" → This skill is NOT for e-commerce. The ebook is the only purchasable item.

### Rule 5: One build, complete output
Generate ALL files in a single pass. The user should receive:
- 9 app files (index + 7 sub-pages + sitemap + robots)
- 3 build tools (setup + updater + demo)
- 2 scripts (launch.sh + github-setup.sh)
- 9 templates (template + 8 tpl files)
- 2 docs (README + SKILL.md or config.json)
- = 25-26 files total

Never deliver partial output. Never say "I'll add that later." The template system means everything is generated at once.

### Rule 6: Niche-specific adaptations to verify

| Template Element | Must Be Customized For Niche |
|---|---|
| Hero headline + tagline | ✅ Always |
| Meta title + description + keywords | ✅ Always |
| Wizard fields (step 1 demographics) | ✅ Change height/weight to niche fields |
| Wizard goals (step 2) | ✅ Replace with niche goals |
| Wizard routine (step 3) | ✅ Replace with niche morning habits |
| Dashboard metrics (6 cards) | ✅ Replace weight/steps with niche metrics |
| Body SVG visualization | ✅ Replace with niche visual (budget gauge, plant, etc.) |
| Progress rings | ✅ Rename and retarget |
| Quick log fields | ✅ Replace with niche daily inputs |
| Biomarkers tab | ✅ Rename + replace with niche advanced metrics |
| Forecast chart | ✅ Re-project for niche goal |
| Phase banners (4 phases) | ✅ Rename to niche journey stages |
| Supplement checklist | ✅ Replace with niche daily checklist |
| Skincare section | ⚠️ Remove or replace with niche protocol |
| Workout plan | ⚠️ Replace with niche actions (or keep if fitness-related) |
| Exercise library + SVGs | ⚠️ Replace with niche activity library |
| Recipes | ⚠️ Replace with niche templates/content cards |
| Food guide (eat/limit/avoid) | ⚠️ Replace with niche do/don't lists |
| Wearable data guide | ⚠️ Replace with "where to find your data" for the niche |
| Offers categories | ✅ Change to niche product categories |
| Ebook content preview | ✅ Customize chapters for niche |
| Terms disclaimer | ✅ Niche-specific legal disclaimer |
| Schema.org type | ✅ May change from HealthApplication |
| FAQ questions | ✅ Rewrite for niche |
| SEO sections | ✅ Rewrite for niche keywords |
